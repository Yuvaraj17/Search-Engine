To deploy, run the following command, or see [here](https://cloud.google.com/appengine/docs/python/gettingstartedpython27/uploading) for more details about uploading your application.

[![Open in Cloud Shell][shell_img]][shell_link]

[shell_img]: http://gstatic.com/cloudssh/images/open-btn.png
[shell_link]: https://console.cloud.google.com/cloudshell/open?git_repo=https://github.com/GoogleCloudPlatform/python-docs-samples&page=editor&open_in_editor=appengine/standard/channel/README.md

`appcfg.py -A <YOUR_PROJECT_ID> update .`

